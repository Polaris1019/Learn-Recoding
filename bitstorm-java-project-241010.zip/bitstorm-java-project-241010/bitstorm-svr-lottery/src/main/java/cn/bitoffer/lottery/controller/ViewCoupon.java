package cn.bitoffer.lottery.controller;

import java.util.Date;

public class ViewCoupon {
    private int prizeId;
    private String code;


    public int getPrizeId() {
        return prizeId;
    }

    public void setPrizeId(int prizeId) {
        this.prizeId = prizeId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
