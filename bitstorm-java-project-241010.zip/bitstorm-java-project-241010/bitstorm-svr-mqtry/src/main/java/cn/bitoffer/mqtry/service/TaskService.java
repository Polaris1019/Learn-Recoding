package cn.bitoffer.mqtry.service;

import cn.bitoffer.mqtry.model.Task;

public interface TaskService {

    void save(Task task);
}
