package cn.bitoffer.leaf.exception;

public class InitException extends Exception{
    public InitException(String msg) {
        super(msg);
    }
}
